import 'package:flutter/material.dart';
import 'package:palette/Screens/campaign_recruited_Screen.dart';
import 'package:palette/widgets/bottom_Bar.dart';

import 'Screens/Selectors_Screen.dart';
import 'Screens/applicants_Screen.dart';
import 'Screens/change_Information_Screen.dart';
import 'Screens/faq_Screen.dart';
import 'Screens/load_campaign_Screen.dart';
import 'Screens/login_Screen.dart';
import 'Screens/main_Screen.dart';
import 'Screens/notice_Screen.dart';
import 'Screens/profile_Screen.dart';
import 'Screens/registering_campaign_Screen.dart';
import 'Screens/signUp_Screen.dart';
import 'Screens/splash_Screen.dart';
void main() async {
  runApp(palette());
}

class palette extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
    //   //    statusBarColor: CustomColors.statusColor
    // ));
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Palette",
      theme: ThemeData(
        primaryColor: Colors.white,
        canvasColor: Colors.white,
      ),
      home:   SplashScreen()
    );
  }
}